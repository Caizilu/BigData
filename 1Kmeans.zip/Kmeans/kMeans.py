# coding=utf-8
from numpy import *
import csv
import codecs
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer

# 原始的作者：wei wang
orginal_author = ['wei wang', '']

# 处理数据,获取标题和作者
def handleData(fileName):
    csv_reader = csv.reader(open(fileName, 'r'))
    dataSet = []
    index = 0
    for row in csv_reader:
        dataSet.append(row[0].strip())
        for i in range(1, 15):
            if row[i].lower().strip() not in orginal_author:
                dataSet[index] += row[i].strip() + ' '
        dataSet[index].strip()
        index += 1
    return dataSet

# 计算权重
def calcWeight(dataSet):
    # 将文本中的词语转换为词频矩阵 矩阵元素a[i][j] 表示j词在i类文本下的词频
    vectorizer = CountVectorizer()
    # 该类会统计每个词语的tf-idf权值
    transformer = TfidfTransformer()
    # 第一个fit_transform是计算tf-idf 第二个fit_transform是将文本转为词频矩阵
    tfidf = transformer.fit_transform(vectorizer.fit_transform(dataSet))
    # 获取词袋模型中的所有词语
    word = vectorizer.get_feature_names()
    # 将tf-idf矩阵抽取出来，元素w[i][j]表示j词在i类文本中的tf-idf权重
    weight = tfidf.toarray()
    print('Features length: ' + str(len(word)))
    resName = "BHTfidf_Result.txt"
    result = codecs.open(resName, 'w', 'utf-8')
    for j in range(len(word)):
        result.write(word[j] + ' ')
    result.write('\r\n\r\n')
    result.close()
    return weight

# 聚类
def kMeans(weight, num_cluster=10):
    km = KMeans(n_clusters=num_cluster)
    km.fit(weight)
    labels = []
    i = 1
    while i <= len(km.labels_):
        labels.append(km.labels_[i - 1])
        i = i + 1
    return km, labels

# 可视化图
def plot(dist, labels, centers):
    pca = PCA(n_components=2)   #设置维度
    newData = pca.fit_transform(dist)    #降为二维
    newCenter = pca.fit_transform(centers)
    centerLabels = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    dataMat = zeros((len(newData), 2))
    centerMat = zeros((len(newCenter), 2))
    for i in range(0, len(labels)):
        labels[i] += 1
    index = 0
    for i in newData:
        dataMat[index,:] = i[0:2]
        index += 1
    index = 0
    for i in newCenter:
        centerMat[index,:] = i[0:2]
        index += 1
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.scatter(dataMat[:, 0], dataMat[:, 1], 15.0*array(labels), 15.0*array(labels))
    ax.scatter(centerMat[:, 0], centerMat[:, 1], 15.0 * array(centerLabels), 15.0 * array(centerLabels), marker='+')
    plt.show()

if __name__=="__main__":
    dataSet = handleData("papers.csv")
    weight = calcWeight(dataSet)
    km, labels = kMeans(weight)
    s = km.fit(weight)
    # 用来评估簇的个数是否合适，距离越小说明簇分的越好，选取临界点的簇个数  958.137281791
    print(km.inertia_)
    print(km.labels_)
    count = pd.Series(km.labels_).value_counts()  # 统计各个类别的数目
    print(count)
    plot(weight, labels, km.cluster_centers_)   # km.cluster_centers_ 中心点
