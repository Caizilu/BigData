# coding=utf-8
from collections import Counter

num = []
result={}
text_file = r"C:\Users\CZL\Desktop\Test\Kmeans\result1.txt"

for line in open(text_file, 'r').readlines():
    # print line
    for num in line.strip():
        for i in num:
            if i in result:
                result[i] += 1
            else:
                result[i] = 1

for i in result:
    if result[i] != 1:
        print("簇类%s 共有元素%d个" % (i, result[i]))

# print result